<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Fifth Street Baptist Church</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#2196f3">

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/fifthstreet.css">
    <link rel="stylesheet" href="css/carousel.css">



    <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
</head>
    
<?php include 'navbar.html'; ?>
     

<div class="center">

    <div class="page-header">
        <h1>Welcome to Fifth Street Baptist Church!</h1>
    </div>
    <p class="lead">Pastor: Rev. Ozzie Vater
        <br>
    </p>
</div>
<hr />
<div class="container">
    <h1>Current Events</h1>
        <div class="row">
             <div class="col-md-4">
            <h3>Youth Lock-in</h3>
          <p><img src="img/lockin.png" class="img-responsive" width="100%"><br />
                <p> Youth lock-in takes place the last saturday in October, a fun and safe alternative to the festivities of downtown. </p>
            <p><a class="btn btn-default" href="https://kideventpro.lifeway.com/myChurch/?id=37355" role="button">Register Online </a> | <a class="btn btn-default" href="files/Youth%20Lock-in%20permission%20slip%20two%20page%202016.pdf" role="button">Print Out Registration Form</a> </p>
            </div> 
            <div class="col-md-4">
            <h3>Dental Health Clinic</h3>
          <p><img src="img/dhc.png" class="img-responsive" width="100%"><br />
                <p> Fifth Street hosted the Mobile Dental Health Clinic <b>Wednesday, Oct. 13th</b> from 10AM to 5PM and <b>Thursday, Oct. 14th</b> from 9AM-1PM. </p>
            <p><a class="btn btn-default" href="http://flbaptist.org/florida-baptist-mobile-dental-ministry/" role="button"> </a></p>
            </div> 
            <div class="col-md-4">
            <h3>Trunk Or Treat</h3>
          <p><img src="img/trunkortreat.png" class="img-responsive" width="100%"><br />
                <p>Please join us for fun and festivities at our Trunk or Treat event October 31st @ 6PM at the church.
</p>
            <p><a class="btn btn-default" href="http://www.firstplace4health.com/" role="button">More info &raquo;</a></p>
            </div> 
           
        </div> 
    <div class="row">
              <div class="col-md-4">
            <h3>Holy Land Experience 2017</h3>
          <p><img src="img/holyland.jpg" class="img-responsive" width="100%"><br />
                <p>Our 10-day Holy Land Classic Tour is perfect for the first time traveler to the Holy Land. On this 10-Day journey you will visit all the major sites, such as the Sea of Galilee, Mt. of Beatitudes, Jordan River, Bethlehem, Nazareth, Jerusalem and more. You will even have the option of taking a day to Masada and swim in the Dead Sea! Enhance your journey with our tour extensions to Egypt, Jordan, Judea and Samaria, Rome, and more!

 </p>
            <p><a class="btn btn-default" href="http://www.eo.travelwithus.com/tours/holy-land-classic-2017#.V_BuHVQrKM8" role="button">Learn More &raquo;</a></p>
            </div>          
        <div class="col-md-4">
            <h3>First Place 4 Health</h3>
          <p><img src="img/fp4h.jpg" class="img-responsive" width="100%"><br />
                <p>Do you want to improve your relationships with others? Do you desire to be physically

fit? Are you tired of being tired? Would you like to know God in a more intimate way? First Place 4 Health, a Christ-centered total-wellness program, will be offered at

5th Street. The weekly meetings will be held every <strong>Sunday from 12:45p-2:00p</strong>. For more information, contact Dave

Parker <a href="mailto:Davepkw@gmail.com">via email</a>. 
</p>
            <p><a class="btn btn-default" href="http://www.firstplace4health.com/" role="button">More info &raquo;</a></p>
            </div> 
            <div class="col-md-4">
            <h3>The Insanity of God</h3>
          <p><img src="img/insanity.png" class="img-responsive" width="100%"><br />
                <p>We will be hosting a Lifeway Simulcast of the movie ''Insanity of God" in the Church Sanctuary on Sunday November 16, 2016, at 7 PM.

 </p>
            <p><a class="btn btn-default" href="http://www.insanityofgodmovie.com/" role="button">Learn More &raquo;</a></p>
            </div>          
        </div> 
    <div class="center"><a href="files/bulletin070316.pdf" class="btn btn-info btn-primary">View Full Builletin</a></div>
   
</div>
<div class="jumbotron center">
    <div class="container">
        <div class="center">
            <h3>Miss last week's sermon?</h3>
            <p>All of our sermons are recorded and are available to listen to on the web!</p>
            <a href="http://www.sermon.net/kwfifthstreet" class="btn btn-primary btn-lg">Listen on Web</a>
            <br />
            <br />
            <p>Now you can get your sermons in portable podcast form!</p>
            <a href="itpc://kwfifthstreet.sermon.net/rss/main" class="btn btn-info btn-primary">Subscribe on iTunes</a>
            <a href="http://kwfifthstreet.sermon.net/rss/main" class="btn btn-danger btn-primary">RSS Feed</a>
        </div>
    </div>
</div>
<?php include 'footer.html'; ?>